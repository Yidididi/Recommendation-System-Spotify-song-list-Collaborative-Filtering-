import h5py

import os


tag_set = set()

def tag_sim(tag1, tag2):
    return float(len(tag1 & tag2)) / len(tag1 | tag2)

data = {}
for i in os.listdir("./data"):
    h5file = h5py.File("./data/"+i, "r")
    data[i] = { "tags": set(h5file["metadata"]["artist_terms"][()].tolist()), "loudness":h5file["analysis"]["songs"]["loudness"][()][0]}


for i in data:
    for j in data:
        print i, "--", j , "  /   " , "%6.2f"%abs(data[i]["loudness"] - data[j]["loudness"]), "/",  tag_sim(data[i]["tags"],   data[j]["tags"])